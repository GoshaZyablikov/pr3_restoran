import Admin
import time
def toAdmin(adminId):
    print("Выход на Главную..")
    time.sleep(1)
    Admin.Admin(adminId)