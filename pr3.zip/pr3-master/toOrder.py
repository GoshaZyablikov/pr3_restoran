import Order
import time
def toOrder(userId):
    print("Выход на Главную..")
    time.sleep(1)
    Order.Orders(userId)